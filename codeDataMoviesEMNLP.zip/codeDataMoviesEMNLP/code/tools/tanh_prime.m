function tanh_prime = tanh_prime(a)
    %a = tanh(input);
    tanh_prime = (1-a.^2);
end